﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Razor.TagHelpers;

//stringwriter
using System.IO;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Mvc.ViewFeatures;  //needed for ViewContext attribute

namespace WebApplication1.TagHelpers
{

    [HtmlTargetElement(Attributes = attName)]
    public class TestTagHelper : TagHelper
    {
        private const string attName = "person-tag";

        private readonly IHtmlHelper _htmlHelper;
        private readonly HtmlEncoder _htmlEncoder;

        public TestTagHelper(IHtmlHelper htmlHelper, HtmlEncoder htmlEncoder)
        {
            _htmlHelper = htmlHelper;
            _htmlEncoder = htmlEncoder;
        }

        [HtmlAttributeName(attName)]
        public HomeModelArgs Args { get; set; }
        public object AppFilterArgs { get; set; }

        [ViewContext]
        [HtmlAttributeNotBound]
        public ViewContext ViewContext { get; set; }

        public override async Task ProcessAsync(TagHelperContext context, TagHelperOutput output)
        {
            //WORKED==>output.TagName = "div";
            //WORKED==>output.Content.Append("Run...");
            //  output.TagMode = TagMode.StartTagAndEndTag;

            var stringAttrib = Args;
            var classbound = AppFilterArgs;


            //var sb = new System.Text.StringBuilder();
            //sb.AppendFormat("<br/><span>Hi! {0}</span>", this.AppFilterArgs);

            //if (this.Args.email != null)
            //{
            //    output.TagName = "a";                                 // Replaces <email> with <a> tag
            //    var content = await output.GetChildContentAsync();
            //    //var target = content.GetContent();
            //    //var target = content.GetContent() + "@" + EmailDomain;
            //    output.Attributes.SetAttribute("href", "mailto:" + this.Args.email);
            //    output.Content.SetContent(content.GetContent() + "-added test");
            //}
            //output.PostElement.SetHtmlContent(sb.ToString());

            (_htmlHelper as IViewContextAware).Contextualize(ViewContext);
            var partial = await _htmlHelper.PartialAsync("MyList", this.Args);
            var writer = new StringWriter();
            partial.WriteTo(writer, _htmlEncoder);

            output.Content.SetHtmlContent(writer.ToString());


        }
    }
}
