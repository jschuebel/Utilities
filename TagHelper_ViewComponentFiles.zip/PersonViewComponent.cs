﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class PersonArg
    {
        public bool isTest { get; set; }
    }
    public class PersonViewComponent : ViewComponent
    {

        List<Person> lst = new List<Person>();
        public PersonViewComponent()
        {
            lst = Person.GetPeople();
        }

        public async Task<IViewComponentResult> InvokeAsync(PersonArg arg)
        {
            var model = lst;
            return await Task.FromResult((IViewComponentResult)View("PeopleGrid", model));
        }

    }
}
