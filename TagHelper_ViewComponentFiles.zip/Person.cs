﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class Person
    {
        public int ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public static List<Person> GetPeople()
        {
            var icons = new List<Person>();
            for(int i=1;i<10;i++)
                icons.Add(new Person { ID = 1, FirstName = $"frank{i}", LastName = "Smith" });
            icons.Add(new Person { ID = 1, FirstName = "jane", LastName = "doe" });
            icons.Add(new Person { ID = 1, FirstName = "andy", LastName = "jones" });

            return icons;
        }

    }
}
