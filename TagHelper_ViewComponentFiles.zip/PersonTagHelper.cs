﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace WebApplication1.TagHelpers
{

    [HtmlTargetElement(Attributes = attName)]
    public class TestTagHelper : TagHelper
    {
        private const string attName = "person-tag";

        [HtmlAttributeName(attName)]
        public HomeModelArgs Args { get; set; }
        public object AppFilterArgs { get; set; }
        //        public override async Task ProcessAsync(TagHelperContext context, TagHelperOutput output)
        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "div";
            output.Content.Append("Run...");

            var t1 = Args;
            var t2 = AppFilterArgs;

            //  output.TagName = "CustumTagHelper";
            //  output.TagMode = TagMode.StartTagAndEndTag;

//            var hld = AppFilterArgs;

//            var sb = new System.Text.StringBuilder();
            //sb.AppendFormat("<span>Hi! {0}</span>", this.Name);
  //          sb.AppendFormat("<span>Hi! </span>");

            //output.TagName = "a";                                 // Replaces <email> with <a> tag
            //var content = await output.GetChildContentAsync();
            //var target = content.GetContent() + "@" + EmailDomain;
            //output.Attributes.SetAttribute("href", "mailto:" + target);
            //output.Content.SetContent(target);


    //        output.PostElement.SetHtmlContent(sb.ToString());
        }
    }
}
